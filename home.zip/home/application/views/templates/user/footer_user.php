  

  <script src="<?= base_url('assets/')?>plugins/jquery/jquery.min.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery/jquery-1.10.2.min.js"></script>
      <script src="<?= base_url('assets/')?>plugins/jquery/main.js"></script>
      <script src="<?= base_url('assets/')?>plugins/jquery/jquery.js"></script> 

      <script type="text/javascript" src="<?= base_url('assets/') ?>js/file_upload.js"></script>
    <!-- Bootstrap Core Js -->
    <script src="<?= base_url('assets/')?>plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/node-waves/waves.js"></script>

    <!-- Custom Js -->
    <script src="<?= base_url('assets/')?>js/admin.js"></script>

    <!-- Demo Js -->
    <script src="<?= base_url('assets/')?>js/demo.js"></script>

    <!-- Autosize Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/autosize/autosize.js"></script>

    <!-- Moment Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/momentjs/moment.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="<?= base_url('assets/')?>plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

  
    <script src="<?= base_url('assets/')?>js/pages/tables/jquery-datatable.js"></script>

    <script src="<?= base_url('assets/')?>plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Bootstrap Datepicker Plugin Js -->
    <script src="<?= base_url('assets/')?>plugins/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

    <script src="<?= base_url('assets/')?>js/pages/forms/basic-form-elements.js"></script>

    <script src="<?= base_url('assets/')?>plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <script src="<?= base_url('assets/') ?>js/maskapai.js"></script>
    <script src="<?= base_url('assets/') ?>js/ulasan.js"></script>

    <!-- Light Gallery Plugin Js -->
    <script src="<?= base_url('assets/') ?>plugins/light-gallery/js/lightgallery-all.js"></script>

    <!-- Custom Js -->
    <script src="<?= base_url('assets/') ?>js/pages/medias/image-gallery.js"></script>
    <script src="<?= base_url('assets/')?>js/pages/cards/colored.js"></script>
     <script src="<?= base_url('assets/')?>plugins/waitme/waitMe.js"></script>
     <script src="<?= base_url('assets/')?>plugins/ckeditor/ckeditor.js"></script>

    <script src="<?= base_url('assets/') ?>js/pages/forms/editors.js"></script>
    
</body>

</html>